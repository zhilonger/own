// redux 的核心，数据的声明改变 逻辑处理都在这里

let initState = {
    list:[],
    userInfo:{}
}

export default function rootReducers(state=initState,action){
//    console.log(action)
    switch(action.type){
        case "ADDCAR":
            state.list.push(action.data);
            console.log(state)
            return state
      
        case "DELCAR":
            state.list.splice(action.data,1)
            return state
        case "LOGIN":
            state.userInfo.name=action.data.name;
            state.userInfo.psd=action.data.psd;
            return state
        default:
           return state
    }
    return state;
}


