// 修改redux 里面的 数据 时要调用的方法
export function addCar(data){
    //方法里面的写法 要固定
    return{
        type:'ADDCAR', 
        data
    }
}

export function delCar(data){
    //方法里面的写法 要固定
    return{
        type:'DELCAR', 
        data:data
    }
}

export function login(data){
    //方法里面的写法 要固定
    return{
        type:'LOGIN', 
        data:data
    }
}









